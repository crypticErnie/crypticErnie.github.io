echo -e "nameserver 103.86.96.100""\n""nameserver 103.86.99.100" > /etc/resolv.conf
exit